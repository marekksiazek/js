const btn = document.querySelector('button')
const div = document.querySelector('div')

const names = ['Jagienka', 'Ania', 'Aneta', 'Ola', 'Julia', 'Patrycja', 'Michalina', 'Judyta'];
const prefixs = ['Wydaje mi się', 'Mam wrażenie', 'Szczerze powiedziawszy myślę', 'Szczerze uważam', 'Na 100% twierdzę', 'Jestem pewien'];

const nameGenerator = () => {
    // SOLUTION #1
    // const indexNames = Math.floor(Math.random() * names.length);
    // const indexPrefix = Math.floor(Math.random() * prefixs.length);
    // div.textContent = `${prefixs[indexPrefix]}, że najlepsze imię będzie ${names[indexNames]}`;

    // SOLUTION #2
    div.textContent = `${prefixs[Math.floor(Math.random() * prefixs.length)]}, że najlepsze imię będzie ${names[Math.floor(Math.random() * names.length)]}`;
}


btn.addEventListener('click', nameGenerator);