const clock = () => {
    let seconds = 1;
    document.body.textContent = `Jesteś na stronie ${seconds} sekund`;

    const timer = () => {
        seconds++;
        document.body.textContent = `Jesteś na stronie ${seconds} sekund`;

    }
    return timer
}

const start = clock();

setInterval(start, 1000);