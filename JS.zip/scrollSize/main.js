const squere = document.createElement("div");
document.body.appendChild(squere);


let grow = true;
let size = 10; // wielkość kwadratu
squere.style.height = size + "px";
squere.style.width = size + "px";

window.addEventListener("scroll", function(){
    
    if (size > window.innerWidth / 2) {
        grow = !grow;
    }
    else if (size <= 0) {
        grow = !grow;
    }
    
    if (grow){
    size += 5;
    squere.style.height = size + "px";
    squere.style.width = size + "px";
    }
    else {
        size -= 5;
        squere.style.height = size + "px";
        squere.style.width = size + "px";
    }

})






//max wielkość kwadratu
//window.innerWidth * 0,5