const input = document.querySelector("input");
const passwords = ["jedEN", 'DwA'];
const messages = ['super', 'dziala'];


// SOLUTION #1
// const div = document.querySelector('div');
// const showMessage = (e) => {
//     // passwords.forEach((password, i) => {
//     //     if (password.toLowerCase() === e.target.value.toLowerCase()) {
//     //         div.textContent = messages[i];
//     //     }
//     // });

// }

//SOLUTION #2 
// const div = document.querySelector('div');
// passwords.forEach((password, index) => {
//     passwords[index] = password.toLowerCase();
// })

// const showMessage = (e) => {
//     const input = e.target.value.toLowerCase();
//     passwords.forEach((password, i) => {
//         if (password === input) {
//             div.textContent = messages[i];
//         }
//     });

// }

// SOLUTION #3 - WYKORZYSTANIE MAP 

const LCPasswords = passwords.map(password => password.toLowerCase());

const div = document.querySelector('div');
const showMessage = (e) => {
    const textInput = e.target.value.toLowerCase();
    for (let i = 0; i < LCPasswords.length; i++) {
        if (textInput === LCPasswords[i]) {
            div.innerHTML = messages[i];
        }
    }

}


input.addEventListener("input", showMessage);