const advices = [];

const btnAdd = document.querySelector(".add");
const btnReset = document.querySelector('.reset');
const btnShowAdvice = document.querySelector('.showAdvice');
const btnShowList = document.querySelector('.showList');

const addAdvice = (e) => {
    e.preventDefault();
    const input = document.querySelector('input');
    const advice = input.value;
    if (input.value) {
        advices.push(advice);
        alert(`Dodałeś do listy możliwości ${advice}`);
        input.value = '';
    }
}

const resetList = (e) => {
    e.preventDefault();
    advices.length = 0;
    const h1 = document.querySelector('h1');
    h1.textContent = "";
}

const showAdvice = () => {
    const advice = advices[Math.floor(Math.random() * advices.length)];
    const h1 = document.querySelector('h1');
    h1.textContent = advice;
}

const showList = () => {
    alert("Twoje możliwości to: " + advices);
}





btnAdd.addEventListener('click', addAdvice);
btnReset.addEventListener('click', resetList);
btnShowAdvice.addEventListener('click', showAdvice);
btnShowList.addEventListener('click', showList);