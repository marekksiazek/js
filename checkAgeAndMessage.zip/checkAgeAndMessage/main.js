const user = (name = "", age) => {
    let userName = name;
    let userAge = age;

    function showName() {
        console.log(`Cześć ${userName}, ${userAge >= 18 ? 'Możesz kupić piwo' : 'Niestety jesteś za młody na piwo'}`);
    }
    return showName
}

const mieszko = user('Mieszko', 20);
const mirek = user('Mirek', 16);
mieszko()
mirek()