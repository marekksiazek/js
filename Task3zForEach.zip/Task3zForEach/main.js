const li = document.querySelectorAll("li")
const btn =document.querySelector("button")
let sizeFont = 10;
btn.style.margin = "10px";

const elementList = function() {
    li.forEach( l => {
        l.style.display = "block";
        l.style.fontSize = sizeFont + "px"
    })
    sizeFont++;



    // for (let i = 0; i < li.length; i++) {
    //     li[i].style.display = "block";
    //     li[i].style.fontSize = sizeFont + "px"
        
    // }
    // sizeFont++;
}

btn.addEventListener("click", elementList)


array.forEach(element => {
    
});