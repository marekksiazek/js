document.body.style.height = "10000px";
const div = document.createElement("div");
document.body.appendChild(div);

let size = 10;
let grow = true;


div.style.width = "100%";
div.style.backgroundColor = "green";
div.style.height = size + "px";
div.style.position = "fixed";
div.style.top = 0;
div.style.left = 0;

window.addEventListener("scroll", changeHeight)

function changeHeight() {
    
    if (size > window.innerHeight / 2){
        grow = !grow;
    }
    else if (size <= 0) {
        grow = !grow;
    }
    if (grow) {
        size +=5;
        div.style.backgroundColor = "green";
    }
    else {
        size -=5;
        div.style.backgroundColor = "red"
    }
    div.style.height = size + "px";
}